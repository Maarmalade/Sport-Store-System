package SportStoreSystem;

import java.util.*;

public interface InventoryManagement {
	void addItem(Items item);
    void removeItem(int itemId);
    void updateItemQuantity(int itemId, int newQuantity);
    void displayItems();
    List<Items> getItems();
}
