package SportStoreSystem;

import java.util.*;

public class SportStoreApps 
{
	 public static void main(String[] args) {
	 
		Scanner scanner = new Scanner(System.in);
		
		Inventory inventory = new Inventory("inventory.txt");
		
        Report report = new Report();
        Billings billing = new Billings();
		 
		boolean loginSuccessful = false;
		
		while (!loginSuccessful) {
            System.out.println("Welcome to the Sport Store System!");
            System.out.println("Are you logging in as:");
            System.out.println("1. Admin");
            System.out.println("2. Customer");
            System.out.print("Enter your choice: ");
            int userTypeChoice = scanner.nextInt();
            scanner.nextLine();

            switch (userTypeChoice) {
                case 1:
                    loginSuccessful = loginAsAdmin();
                    break;
                case 2:
                    loginSuccessful = loginAsCustomer();
                    break;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
		
		 scanner.close();
    }

    private static boolean loginAsAdmin() {
    	
    	Scanner scanner = new Scanner(System.in);
    	String adminFilename = "admin.txt"; 
    	
        System.out.println("Enter admin username:");
        String username = scanner.nextLine();
        System.out.println("Enter admin password:");
        String password = scanner.nextLine();

        Admin admin = new Admin(username, password, adminFilename);

        if (admin.authenticate(username, password)) {
        	System.out.println("Welcome to the Sport Store System!");
    		System.out.println("Please select an option:");
    		System.out.println("1. Add item to inventory");
    		System.out.println("1. Update items from inventory");
    		System.out.println("1. Remove items from inventory");
    		
    		System.out.println("2. Update/Maintain customer orders");
    		
    		System.out.println("3. Manage billing statements");
    		
    		System.out.println("4. Display inventory");
    		System.out.println("4. Generate inventory report");
    		System.out.println("4. Generate sales report");
    		
    		System.out.println("5. Create user profile");
    		
    		System.out.println("8. Exit");
            // Provide admin options menu
            scanner.close();
            return true;
        } else {
            System.out.println("Invalid username or password. Admin login failed. Please try again.");
            scanner.close();
            return false;
        }
    }

    private static boolean loginAsCustomer() {
    	
    	Scanner scanner = new Scanner(System.in);
    	String customerFilename = "customers.txt";	
    	
        System.out.println("1. Login as existing customer");
        System.out.println("2. Create new account");
        System.out.print("Enter your choice: ");
        int customerOpt = scanner.nextInt();
        scanner.nextLine();

        switch (customerOpt) {
            case 1:
                System.out.println("Enter customer username:");
                String username = scanner.nextLine();
                System.out.println("Enter customer password:");
                String password = scanner.nextLine();

                Customer customer = new Customer(username, password, customerFilename);

                if (customer.authenticate(username, password)) {
                	System.out.println("Welcome to the Sport Store System!");
            		System.out.println("Please select an option:");
            		System.out.println("1. Display inventory");
            		System.out.println("2. Place an order");
            		System.out.println("3. Display orders");
            		System.out.println("4. Exit");
                    // Provide customer options menu
                    scanner.close();
                    return true;
                    
                } else {
                	System.out.println("Invalid username or password. Customer login failed. Please try again.");	
                    scanner.close();
                    return false;
                }
                
            case 2:
            	System.out.println("Enter customer username:");
                String customerUsername = scanner.nextLine();
                System.out.println("Enter customer password:");
                String customerPassword = scanner.nextLine();

                Customer newcustomer = new Customer(customerUsername, customerPassword, customerFilename);
                
                newcustomer.registerCustomer(customerUsername, customerPassword);
                
                System.out.println("Customer registration successful!");
                scanner.close();
                return true;
                
            default:
                System.out.println("Invalid choice! Please try again.");
                scanner.close();
                return false;
        }
       
    }  
}
	
			
		
		 
		
		/*
		int choice = scanner.nextInt();
		scanner.nextLine(); // Consume newline
		
		switch (choice) {
		    case 1:
		        System.out.println("Enter item details (ID, Name, Price, Quantity):");
		int id = scanner.nextInt();
		scanner.nextLine(); // Consume newline
		String name = scanner.nextLine();
		double price = scanner.nextDouble();
		int quantity = scanner.nextInt();
		
		Items newItem = new Items(id, name, price, quantity);
		inventory.addItem(newItem);
		
		System.out.println("Item added successfully!");
		    break;
		    
		    
		case 2:
		    System.out.println("Enter item ID to update quantity:");
		int itemId = scanner.nextInt();
		System.out.println("Enter new quantity:");
		int newQuantity = scanner.nextInt();
		inventory.updateItemQuantity(itemId, newQuantity);
		System.out.println("Item quantity updated successfully!");
		    break;
		case 3:
		    System.out.println("Enter item ID to remove from inventory:");
		int removeId = scanner.nextInt();
		inventory.removeItem(removeId);
		System.out.println("Item removed successfully!");
		    break;
		case 4:
		    System.out.println("Inventory:");
		    inventory.displayItems();
		    break;
		case 5:
		    System.out.println("Generating inventory report...");
		    report.generateInventoryReport(inventory.getItems());
		    break;
		case 6:
		    // Add code for placing an order
		    break;
		case 7:
		    System.out.println("Orders:");
		    billing.displayOrders();
		    break;
		case 8:
		    // Add code for generating sales report
		    break;
		case 9:
		    System.out.println("Exiting...");
		    System.exit(0);
		    break;
		default:
		    System.out.println("Invalid choice! Please try again.");
		            break;
		    }
		    
		    scanner.close();
		    */

