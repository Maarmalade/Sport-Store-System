package SportStoreSystem;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Admin extends UserProfile
{
	private String adminFilename;
	
	public Admin(String username, String password, String adminFilename) {
        super(username, password);
        this.adminFilename = adminFilename;
	}
        
        public boolean authenticate(String username, String password) {
	        try {
	            BufferedReader reader = new BufferedReader(new FileReader(adminFilename));
	            String line;
	            while ((line = reader.readLine()) != null) {
	                String[] parts = line.split(",");
	                String storedUsername = parts[0];
	                String storedPassword = parts[1];
	                if (username.equals(storedUsername) && password.equals(storedPassword)) {
	                    reader.close();
	                    return true;
	                }
	            }
	            reader.close();
	            
	        } 
	        
	        catch (IOException e) {
	            e.printStackTrace();
	        }
	        
	        return false;
	    }
}
