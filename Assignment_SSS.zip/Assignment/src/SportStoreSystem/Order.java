package SportStoreSystem;

import java.util.*;

public class Order 
{
	 	private int orderId;
	    private List<Items> items;
	    private double totalAmount;

	    // Constructor
	    public Order(int orderId) {
	        this.orderId = orderId;
	        items = new ArrayList<>();
	        totalAmount = 0.0;
	    }

	    // Method to add an item to the order
	    public void addItem(Items item) {
	        items.add(item);
	        totalAmount += item.getPrice();
	    }

	    // Method to remove an item from the order
	    public void removeItem(Items item) {
	        items.remove(item);
	        totalAmount -= item.getPrice();
	    }
	    
	    public int getOrderId() {
	        return orderId;
	    }
	    
	    // Method to get total amount of the order
	    public double getTotalAmount() {
	        return totalAmount;
	    }

	    // Method to display order details
	    public void displayOrder() {
	        System.out.println("Order ID: " + orderId);
	        System.out.println("Items:");
	        for (Items item : items) {
	        	System.out.println(item);
	        }
	        System.out.println("Total Amount: $" + totalAmount);
	    }
}
