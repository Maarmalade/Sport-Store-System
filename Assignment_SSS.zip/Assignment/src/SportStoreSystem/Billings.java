package SportStoreSystem;

import java.util.*;

public class Billings 
{
	private List<Order> orders;

    // Constructor
    public Billings() {
        orders = new ArrayList<>();
    }

    // Method to place a new order
    public void placeOrder(Order order) {
        orders.add(order);
    }

    // Method to generate bill for an order
    public void generateBill(Order order) {
        // Code to generate bill for an order
    }

    // Method to display all orders
    public void displayOrders() {
        for (Order order : orders) {
            order.displayOrder();
        }
    }
}
