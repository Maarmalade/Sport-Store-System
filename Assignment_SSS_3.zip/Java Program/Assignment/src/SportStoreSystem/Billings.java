package SportStoreSystem;

import java.io.*;

public class Billings 
{
	private Order order;
	private double discountRate;
    private double taxRate;
    private String billingsFilename;

    // Constructor
    public Billings(Order order, String billingsFilename) {
        this.order = order;
        this.billingsFilename = billingsFilename;
        loadConfig();
    }

    // Method to generate bill for an order
    public double generateBill() {
		
		double totalCost = order.getTotalAmount();
		
		// Apply discount
		double discount = totalCost * discountRate;
		totalCost -= discount;
		
		// Apply SST tax
		double tax = totalCost * taxRate;
		totalCost += tax;     
		
		return totalCost;
    }
    
 // Method to save tax and discount rates to a text file
    public void saveConfig() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(billingsFilename))) {
            writer.write(discountRate + "," + taxRate);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Method to load tax and discount rates from a text file
    public void loadConfig() {
    	File file = new File(billingsFilename);
    	
    	if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) 
            	{
                	e.printStackTrace();
            	}
    	}
    	else {
	        try (BufferedReader reader = new BufferedReader(new FileReader(billingsFilename))) {
	            String line;
	            while ((line = reader.readLine()) != null) {
	            	String[] parts = line.split(",");
	                if (parts.length == 2) {
	                    discountRate = Double.parseDouble(parts[0].trim());
	                    taxRate = Double.parseDouble(parts[1].trim());
	                }
	            }
	        }catch (IOException e) {
	        	e.printStackTrace();     
	        }
    	}
    }
    
    public double getDiscountRate() {
        return discountRate;
    }

    public void setDiscountRate(double discountRate) {
        this.discountRate = discountRate;
    }

    public double getTaxRate() {
        return taxRate;
    }

    public void setTaxRate(double taxRate) {
        this.taxRate = taxRate;
    }
}
