package SportStoreSystem;

import java.util.*;
import java.io.*;

public class Report 
{	
	private Map<Integer, Integer> readInitialQuantities() {
	    Map<Integer, Integer> initialQuantities = new HashMap<>();
	    try (BufferedReader reader = new BufferedReader(new FileReader("initial_quantities.txt"))) {
	        String line;
	        while ((line = reader.readLine()) != null) {
	            String[] parts = line.split(",");
	            int itemId = Integer.parseInt(parts[0]);
	            int initialQuantity = Integer.parseInt(parts[1]);
	            initialQuantities.put(itemId, initialQuantity);
	        }
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	    return initialQuantities;
	}
	
	public void generateInventoryReport(List<Items> items, String filename) {
	    // Retrieve initial quantities from file
	    Map<Integer, Integer> initialQuantities = readInitialQuantities();

	    File file = new File(filename);

	    try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
	        if (!file.exists()) {
	            file.createNewFile();
	        }

	        // Write initial quantity for each item to the file
	        writer.write("Initial Quantity:\n");
	        for (Items item : items) {
	            Integer initialQuantity = initialQuantities.get(item.getId());
	            if (initialQuantity != null) {
	                writer.write("Item: " + item.getName() + ", Initial Quantity: " + initialQuantity + "\n");
	            }
	        }

	        Map<String, Integer> salesMap = new HashMap<>(); // Map to store total sales for each item

	        // Iterate over each item in the inventory
	        for (Items item : items) {
	            String itemName = item.getName();
	            int quantitySold = initialQuantities.getOrDefault(item.getId(), 0) - item.getQuantity(); // Calculate quantity sold
	            salesMap.put(itemName, quantitySold); // Store total sales for this item
	        }

	        // Write the sales report to the file
	        writer.write("\nInventory Report:\n");
	        for (Map.Entry<String, Integer> entry : salesMap.entrySet()) {
	            writer.write("Item: " + entry.getKey() + ", Total quantity sold : " + entry.getValue() + "\n");
	        }
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}
	
	public void printFileContents(String filename) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
