package SportStoreSystem;

import java.util.*;

public class SportStoreApps 
{ 
	public static void main(String[] args) {
	 
		Scanner scanner = new Scanner(System.in);
		 
		boolean loginSuccessful = false;
		
		while (!loginSuccessful) {
            System.out.println("Welcome to the Sport Store System!");
            System.out.println("Are you logging in as:");
            System.out.println("1. Admin");
            System.out.println("2. Customer");
            System.out.print("Enter your choice: ");
            
            int userTypeChoice = scanner.nextInt();
            scanner.nextLine();

            switch (userTypeChoice) {
                case 1:
                    loginSuccessful = loginAsAdmin();
                    break;
                case 2:
                    loginSuccessful = loginAsCustomer();
                    break;
                default:
                    System.out.println("Invalid choice! Please try again.");
                    break;
            }
            
        }
		
		 scanner.close();
    }

    private static boolean loginAsAdmin() {
    	
    	Scanner scanner = new Scanner(System.in);
    	boolean verifiedAdmin = false;   	
    	while (!verifiedAdmin) {	    	
	    	String adminFilename = "admin.txt"; 
	    	String customerFilename = "customers.txt";
	    	String billingFilename = "billing.txt";
	    	String reportFilename = "inventory_report.txt";
	    	Order order = new Order(1);
	    	Inventory inventory = new Inventory("inventory.txt");	    	
	        Report report = new Report();	
	        boolean loggedInAdmin = false;
	        
	        
	        System.out.println("Enter admin username:");
	        String username = scanner.nextLine();
	        System.out.println("Enter admin password:");
	        String password = scanner.nextLine();
	
	        Billings billing = new Billings(order, billingFilename);
	        Customer customer = new Customer(username, password, customerFilename);
	        Admin admin = new Admin(username, password, adminFilename);
	        
	        if (admin.authenticate(username, password)) {
	        	loggedInAdmin = true;
	        	
	        	while (loggedInAdmin) {
		        	System.out.println("Welcome to the Sport Store System!");
		    		System.out.println("Please select an option:");
		    		System.out.println("1. Create Items");
		    		System.out.println("2. Manage billing statements");
		    		System.out.println("3. Generate report on inventory and sales");
		    		System.out.println("4. Create user profile");
		    		System.out.println("5. Exit");
		    		
		    		int adminChoice = scanner.nextInt();
		            scanner.nextLine();
		            
		    		switch (adminChoice)
		    		{
		    			
		    			case 1: 
		    				boolean itemMenuActive = true;
		    				while (itemMenuActive) {
			    				System.out.println("1. Add item to inventory");
			    	    		System.out.println("2. Update items from inventory");
			    	    		System.out.println("3. Remove items from inventory");
			    	    		System.out.println("4. Exit items menu");
			    	    		System.out.print("\n>> ");
			    	    		
			    	    		int adminOpt = scanner.nextInt();
			    	            scanner.nextLine(); 
			    	            
			    	            switch (adminOpt)
			    	            {
			    	            	case 1:
			    	            		
			    	            		int id = 0; 		
			    	            		boolean idUsed = true;
			    	            		while (idUsed) {   
			    	            			System.out.print("\nEnter item ID : ");
				    	                    id = scanner.nextInt();
				    	                    scanner.nextLine(); // Consume newline
				    	                    if (inventory.getItemById(id) == null) {			    	                    	
				    	                    	idUsed = false;
				    	                    }	
				    	                    
				    	                    else {
				    	                    	System.out.println("Item ID already exists. Please choose a different ID.");
				    	                    }
			    	            		}
			    	            		
			    	                    System.out.print("\nEnter items name : ");
			    	                    String name = scanner.nextLine();
			    	                    
			    	                    System.out.print("\nEnter item price : ");
			    	                    double price = scanner.nextDouble();
			    	                    
			    	                    boolean addQuantityVerify = true;
			    	                    
			    	                    while (addQuantityVerify) {
	
				    	                    System.out.print("\nEnter item quantity : ");
				    	                    int quantity = scanner.nextInt();				    	                   
				    	                    		    	                  
				    	                    if (quantity != 0)
				    	                    {
				    	                    	Items newItem = new Items(id, name, price, quantity);
					    	                    inventory.addItem(newItem);
					    	                    System.out.println("Item added successfully!");
					    	                    addQuantityVerify = false;
				    	                    }
			    	                    
				    	                    
				    	                    else
				    	                    {
				    	                    	System.out.println("Cannot add item with 0 quantity! ");
				    	                    	
				    	                    }
				    	                    
			    	                    }
			    	                    break;
			    	                    
			    	            	case 2:
			    	            		
			    	            		System.out.println("Enter item ID to update items:");
			    	            		int itemId = scanner.nextInt();
			    	            		scanner.nextLine(); // Consume newline
			
			    	            		Items itemToUpdate = inventory.getItemById(itemId);
			    	            		
			    	            		if (itemToUpdate != null) {
				    	            		System.out.println("Enter new name:");
				    	            		String newName = scanner.nextLine();
				
				    	            		System.out.println("Enter new price:");
				    	            		double newPrice = scanner.nextDouble();
				
				    	            		inventory.updateItemAdmin(itemId, newName, newPrice);
				    	            		System.out.println("Item updated successfully!");
						    	          
			    	            		}
			    	            		else {
			    	                        System.out.println("No item found with ID " + itemId + " to update.");
			    	            		}
			    	            		
			    	            		break;
			    	                    
			    	            	case 3:
			    	            		
			    	            		 System.out.println("Enter item ID to remove from inventory:");
			    	                     int removeId = scanner.nextInt();
			    	                     
			    	                     Items itemToRemove = inventory.getItemById(removeId);
			    	                     
			    	                     if (itemToRemove != null) {
				    	                     inventory.removeItem(removeId);
				    	                     System.out.println("Item removed successfully!");			    	                     
			    	                     }
			    	                     
			    	                     else {
				    	                        System.out.println("No item found with ID " + removeId + " to remove.");
				    	            		}
			    	                     
			    	                     break;
			    	                     
			    	            	case 4:
			    	                     itemMenuActive = false; // Exit the item menu loop
			    	                     break;
			    	                     
			    	                default:
			    	                     System.out.println("Invalid option. Please try again.");
			    	            }    
		    	           
		    				}
		    				break;
		    				
		    				
		    			case 2:
		    				System.out.println("Manage billing statements:");
		    			    System.out.println("Enter discount rate : ");
		    			    double discountRate = scanner.nextDouble() / 100.0;
		    			    billing.setDiscountRate(discountRate);
		    			
		    			    System.out.println("Enter tax rate : ");
		    			    double taxRate = scanner.nextDouble() / 100.0;
		    			    billing.setTaxRate(taxRate);
		    			    
		    			    billing.saveConfig();
		    			   
		    			    System.out.println("Updated discount rate : " + discountRate + "%");
		    			    System.out.println("Updated tax rate : " + taxRate + "%");
		    			    

		                    break;
		    				
		    			case 3:
		    				boolean inventoryMenu = true;
		    				while (inventoryMenu) {
			    				System.out.println("1. Display inventory");
			    	    		System.out.println("2. Generate inventory report");
			    	    		System.out.println("3. Generate sales report");
			    	    		System.out.println("4. Exit report page");
			    	    		System.out.print("\n>> ");
			    				
			    	    		int adminOpt2 = scanner.nextInt();
			    	            scanner.nextLine(); 
			    	            
			    	            switch (adminOpt2)
			    	            {
			    	            	case 1:
			    	            		System.out.println("Inventory:");
			    	                    inventory.displayItems();
			    	                    break;
			    	                    
			    	            	case 2:
			    	            		
			    	            		System.out.println("Generating inventory report...\n");
			    	                    report.generateInventoryReport(inventory.getItems(), reportFilename);
			    	                    report.printFileContents(reportFilename);
			    	                    break;
			    	                    
			    	            	case 3:
			    	            		break;
			    	            		
			    	            	case 4:
			    	            		inventoryMenu = false;
			    	            		break;
			    	            }
			    	            
		    				}
		    				break;
		
		    			case 4:
		    				
		    				System.out.println("1. Add new admin");
		    	    		System.out.println("2. Remove existing admin");
		    	    		System.out.println("3. Remove existing customer");
		    	    		System.out.print("\n>> ");
		    	    		
		    	    		int adminOpt3 = scanner.nextInt();
		    	            scanner.nextLine();
		    	            
		    	            switch (adminOpt3)
		    	            {
		    	            	case 1:
		    	            		
		    	            		boolean adminRegistration = true;
		    		            	
		    		            	while (adminRegistration) {
		    		            		System.out.println("Enter new admin username:");
					                    String adminUsername = scanner.nextLine();
					                    System.out.println("Enter new admin password:");
					                    String adminPassword = scanner.nextLine();
		    			
		    		            		Admin newAdmin = new Admin(adminUsername, adminPassword, adminFilename);
		    			                
		    			                if (newAdmin.usernameExists(adminUsername)) {
		    			                    System.out.println("Username already exists. Please choose another username.");
		    			                    adminRegistration = false;
		    			                    break;
		    			                }           
		    			                
		    			                newAdmin.register(adminUsername, adminPassword);
		    			                
		    			                System.out.println("New admin registration successful!");
		    			                adminRegistration = false;
		    		            	}
		    		            	break;
			                    
		    	            	case 2:
		    	            		boolean adminRemove = true;
		    	            		
		    	            		while (adminRemove) {
								        System.out.println("Enter current admin username to remove:");
								        String adminUsernameRemove = scanner.nextLine();
								        
								        // Check if the admin username exists
								        if (admin.usernameExists(adminUsernameRemove)) {
								            // If the username exists, delete the admin account
								            admin.deleteAccount(adminUsernameRemove);
								            System.out.println("Admin removed successfully!");
								            adminRemove = false;
								        } 
								        
								        else {
								            // If the username doesn't exist, inform the user
								            System.out.println("Admin username does not exist. Please enter a valid username.");
								        }
		    	            		}
		    	            		break;
		    	            		                 
		    	            	case 3:
		    	            		
		    	            		boolean customerRemove = true;
		    	            		while (customerRemove) {
			    	            		System.out.println("Enter current customer username to remove:");
					                    String customerUsernameRemove = scanner.nextLine();
					                    
					                    if (customer.usernameExists(customerUsernameRemove)) {
					                    	customer.deleteAccount(customerUsernameRemove);
					                    	System.out.println("Customer removed successfully!");
								            customerRemove = false;
					                    }
					                    
					                    else {
								            // If the username doesn't exist, inform the user
								            System.out.println("Customer username does not exist. Please enter a valid username.");
								        }
		    	            		}
		    	            		break;
			    	            }
		    	            break;
		    	            
		    			case 5:
		    				System.out.println("Exiting...");
		    				return false;                  
		                    
		    			default:
		                    System.out.println("Invalid choice! Please try again.");
		                    break;
		    		}
	        	}
	            
	        }
	        
	        else {
	            System.out.println("Invalid username or password. Admin login failed. Please try again.");
	        }        
    	}
    	
    	scanner.close();
    	return verifiedAdmin;
    }

    private static boolean loginAsCustomer() {
    	
    	Scanner scanner = new Scanner(System.in);
    	String customerFilename = "customers.txt";	
    	Inventory inventory = new Inventory("inventory.txt");
    	boolean loggedIn = false;
    	Order order = new Order(1);
        Billings billings = new Billings(order, "billing.txt");
    	
    	while (!loggedIn) {
	        System.out.println("1. Login as existing customer");
			System.out.println("2. Create user profile");
			System.out.println("3. Quit");
	        System.out.print("Enter your choice: ");
	        int customerOpt = scanner.nextInt();
	        scanner.nextLine();
	
	        switch (customerOpt) {
	            case 1:
	                System.out.println("Enter customer username:");
	                String username = scanner.nextLine();
	                System.out.println("Enter customer password:");
	                String password = scanner.nextLine();
	
	                Customer customer = new Customer(username, password, customerFilename);
	                
	                if (customer.authenticate(username, password)) {
	                	loggedIn = true;
	                	
	                	while (loggedIn) {
		                	System.out.println("Welcome to the Sport Store System!");
		            		System.out.println("Please select an option:");
		            		System.out.println("1. Display inventory");
		            		System.out.println("2. Update/Maintain customer orders"); 
		            		System.out.println("3. Display billings");
		            		System.out.println("4. Exit");
		
		            		int customerChoice = scanner.nextInt();
		                    scanner.nextLine();		                   		                 
		                    
		                    switch (customerChoice)
		                    {
			                    case 1:
			                    	
				            		System.out.println("Inventory:");
				                    inventory.displayItems();
				                    break;
				                    
			                    case 2:
			                    	// Update/Maintain customer orders
			                        boolean maintainOrders = true;
			                      
			                        while (maintainOrders) {
			                            System.out.println("Update/Maintain customer orders:");
			                            System.out.println("1. Place an order");
			                            System.out.println("2. Remove items from an order");
			                            System.out.println("3. Back");
			                            System.out.print("Enter your choice: ");
			                            int maintainChoice = scanner.nextInt();
			                            scanner.nextLine();
			                            			                            
			                            switch (maintainChoice) {
						                    case 1:
						                        // Place an order
						                        boolean continueAddingItems = true;                       
						                        
						                        while (continueAddingItems) {
						                            // Prompt user to enter item details
						                            System.out.println("Enter item ID to add to order:");
						                            int itemId = scanner.nextInt();
						                            scanner.nextLine(); // Consume newline
						                            Items item = inventory.getItemById(itemId);
						                            
						                            if (item != null) {
						                            	 // Prompt user to enter quantity
						                                System.out.println("Enter quantity:");
						                                int quantity = scanner.nextInt();
						                                scanner.nextLine(); // Consume newline
						                                                            

						                                if (quantity > item.getQuantity()) {
						                                    // Quantity exceeds available quantity
						                                    System.out.println("Error: Entered quantity exceeds available quantity. Please try again.");
						                                    System.out.println("Do you want to add more items to the order? (y/n)");
						                                    String choice = scanner.nextLine();
						                                    if (!choice.equalsIgnoreCase("y")) {
						                                        continueAddingItems = false;
						                                        break; // Exit the loop
						                                    }
						                                    continue; // Go to next iteration of the loop
						                                }
						                                
						                                order.addItem(new Items(item.getId(), item.getName(), item.getPrice(), quantity));
						                                inventory.updateItem(itemId, item.getName(), item.getPrice(), item.getQuantity() - quantity);
					                                    System.out.println("Item added to order successfully!");
			
						                            } 
						                            
						                            else {
						                                System.out.println("Item with ID " + itemId + " not found in inventory.");
						                            }
						                            
						                            // Ask if the customer wants to continue adding items
						                            System.out.println("Do you want to add more items to the order? (y/n)");
						                            String choice = scanner.nextLine();
						                            if (!choice.equalsIgnoreCase("y")) {
						                                continueAddingItems = false;
						                            }

						                        }
						                        break;
						                        
			                        		
						                    case 2:
						                    	
						                    	boolean continueRemovingItems = true; 
						                    	
						                    	while (continueRemovingItems) {
							                    	// Remove items from an order
							                        System.out.println("Enter the item ID to remove from order :");
							                        int removeItemId = scanner.nextInt();
							                        scanner.nextLine(); // Consume newline
							                        Items item1 = inventory.getItemById(removeItemId);
							                        Items orderitem = null;
							                        
							                        // Find the item in the order
							                        for (Items orderItem : order.getItems()) {
							                            if (orderItem.getId() == removeItemId) {
							                                orderitem = orderItem;
							                                break;
							                            }
							                        }
							                        
							                        if (orderitem != null) {
							                            // Prompt user to enter quantity to remove
							                            System.out.println("Enter the quantity to remove:");
							                            int quantityToRemove = scanner.nextInt();
							                            scanner.nextLine(); // Consume newline
							                            
							                            if (quantityToRemove > orderitem.getQuantity()) {
						                                    // Quantity exceeds available quantity
						                                    System.out.println("Error: Entered quantity exceeds available quantity. Please try again.");
						                                    System.out.println("Do you want to remove items from the order? (y/n)");
						                                    String choice1 = scanner.nextLine();
						                                    if (!choice1.equalsIgnoreCase("y")) {
						                                    	continueRemovingItems = false;
						                                        break; // Exit the loop
						                                    }
						                                    continue; // Go to next iteration of the loop					                                                      
							                            }

							                            order.removeItem(new Items(orderitem.getId(), orderitem.getName(), orderitem.getPrice(), quantityToRemove));
							                            inventory.updateItem(removeItemId, item1.getName(), item1.getPrice(), item1.getQuantity() + quantityToRemove);                          
							                            
							                            System.out.println("Item removed from the order successfully!");
							                        } 
							                        
							                        else {
							                            System.out.println("Item not found in the order.");
							                        }
							                        
							                        // Ask if the customer wants to continue remove items
						                            System.out.println("Do you want to continue removing items from the order? (y/n)");
						                            String choice2 = scanner.nextLine();
						                            if (!choice2.equalsIgnoreCase("y")) {
						                            	continueRemovingItems = false;
						                            }
							                      
						                    	}
						                    	break;
						                    	
							                    case 3:
							                        // Back
							                        maintainOrders = false;
							                        break;
	
							                    default:
							                        System.out.println("Invalid choice! Please try again.");
							                        
			                            }		                            
			                            
			                        }    
			                        break;
			                    			
						                    case 3:
						                    	// View current order
						                        if (!order.isEmpty()) {
						                            System.out.println("\nCurrent Order:");
						                            double finalCost = billings.generateBill();
						                            order.displayOrder();
						                            
						                            System.out.println("\nGrand total after tax and applicable discount: $" + finalCost);
						                            System.out.println();
						                        }
						                            
						                        else {
						                            System.out.println("No orders placed yet.");
						                        }
						                        
						                    	break;
						                    	
						                    case 4:
				                                loggedIn = false;
				                                break;
				                                
						                    default:
						                        System.out.println("Invalid choice! Please try again.");
						                        
		                    }		                    
	                	}
	                	
	                }
    
	                else {
	                	System.out.println("Invalid username or password. Customer login failed. Please try again.");	

	                } 
	                break;
	                
	            case 2:
	            	boolean customerRegistrationSuccessful = true;
	            	
	            	while (customerRegistrationSuccessful) {
		            	System.out.println("Enter new customer username:");
		                String customerUsername = scanner.nextLine();
		                System.out.println("Enter new customer password:");
		                String customerPassword = scanner.nextLine();
		
		                Customer newcustomer = new Customer(customerUsername, customerPassword, customerFilename);
		                
		                if (newcustomer.usernameExists(customerUsername)) {
		                    System.out.println("Username already exists. Please choose another username.");
		                    customerRegistrationSuccessful = false;
		                    break;
		                }           
		                
		                newcustomer.register(customerUsername, customerPassword);
		                
		                System.out.println("New customer registration successful!");
		                customerRegistrationSuccessful = false;
	            	}
	            	break;
	            	
	            case 3:
	                // Back to main login screen
	                return false; // Exiting the method
	                
	            default:
	                System.out.println("Invalid choice! Please try again.");
	                return false;
	        }
    	}  
        scanner.close();
        return loggedIn;
    }
}
	
	