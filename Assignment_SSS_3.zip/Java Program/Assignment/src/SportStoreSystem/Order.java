package SportStoreSystem;

import java.util.*;

public class Order 
{
	    private List<Items> items;
	    private double totalAmount;

	    // Constructor
	    public Order(int orderId) {
	        items = new ArrayList<>();
	        totalAmount = 0.0;
	    }
	    
	    public List<Items> getItems() {
	        return items;
	    }

	    // Method to add an item to the order
	    public void addItem(Items item) {
	    	// Check if the item already exists in the order
	        boolean found = false;
	        for (Items existingItem : items) {
	            if (existingItem.getId() == item.getId()) {
	                // Update the quantity of the existing item
	                existingItem.setQuantity(existingItem.getQuantity() + item.getQuantity());
	                found = true;
	                break;
	            }
	        }
	        // If the item is not found, add it to the order
	        if (!found) {
	            items.add(item);
	        }
	        // Recalculate the total amount
	        calculateTotalAmount();
	    }


	    // Method to remove an item from the order
	    public void removeItem(Items item) {
	        // Find the item in the order
	        for (Items orderItem : items) {
	            if (orderItem.getId() == item.getId()) {
	            	
	                    // Subtract the quantity to remove from the order's quantity
	                    orderItem.setQuantity(orderItem.getQuantity() - item.getQuantity());	                 
		                break;
	                }
	            }   
	        
	     // Recalculate the total amount
            calculateTotalAmount();
	    }
   	
	    public void calculateTotalAmount()
	    {
	    	totalAmount = 0.0;
	        for (Items orderItem : items) {
	            totalAmount += orderItem.getPrice() * orderItem.getQuantity();
	        }
	    }

	    // Method to display order details
	    public void displayOrder() {
	        System.out.println("Items in order");
	        for (Items item : items) {
	        	System.out.println(item);
	        }
	        System.out.println("Total Amount: $" + totalAmount);
	    }
	    
	    
	    public double getTotalAmount() {
	        return totalAmount;
	    }
	    
	    public boolean isEmpty() {
	        return items.isEmpty();
	    }
}
