package SportStoreSystem;

import java.io.*;
import java.util.*;

public class Customer extends UserProfile{
	
	private String customerFilename;
	
	public Customer(String username, String password, String customerFilename) {
	        super(username, password);
	        this.customerFilename = customerFilename;
	    }
	
	    // Method to authenticate customer login 
	@Override
	public boolean authenticate(String username, String password) {
		 try {
	         BufferedReader reader = new BufferedReader(new FileReader(customerFilename));
	         String line;
	         while ((line = reader.readLine()) != null) {
	             String[] parts = line.split(",");
	             String storedUsername = parts[0];
	             String storedPassword = parts[1];
	             if (username.equals(storedUsername) && password.equals(storedPassword)) {
	                 reader.close();
	                 return true;
	             }
	         }
	         reader.close();
	     } catch (IOException e) {
	         e.printStackTrace();
	     }
	     return false;
	 }
	
	public void register(String username, String password) {
        
		File file = new File(customerFilename);
		
		if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) 
            	{
                	e.printStackTrace();
            	}
    	}
		
		else {
	
			try {
	            BufferedWriter writer = new BufferedWriter(new FileWriter(customerFilename, true));
	            writer.write(username + "," + password + "\n");
	            writer.close();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	}
	
	public void deleteAccount(String customerUsernameRemove) {
        // Read the contents of the file into memory
        List<String> lines = new ArrayList<>();
        try {
            BufferedReader reader = new BufferedReader(new FileReader(customerFilename));
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        // Identify the line corresponding to the customer to remove
        int indexToRemove = -1;
        for (int i = 0; i < lines.size(); i++) {
            String[] parts = lines.get(i).split(",");
            if (parts[0].equals(customerUsernameRemove)) {
                indexToRemove = i;
                break;
            }
        }

        // Remove the line if found
        if (indexToRemove != -1) {
            lines.remove(indexToRemove);
        } 

        // Write the updated list of customers back to the file
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(customerFilename));
            for (String line : lines) {
                writer.write(line);
                writer.newLine();
            }
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
	
	public boolean usernameExists(String customerUsernameToCheck) {
	    try {
	        BufferedReader reader = new BufferedReader(new FileReader(customerFilename));
	        String line;
	        while ((line = reader.readLine()) != null) {
	            String[] parts = line.split(",");
	            String storedUsername = parts[0];
	            if (customerUsernameToCheck.equals(storedUsername)) {
	                reader.close();
	                return true; // Username already exists
	            }
	        }
	        reader.close();
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	    return false; // Username doesn't exist
	}
}
	



