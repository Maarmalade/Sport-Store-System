package SportStoreSystem;

import java.io.*;
import java.util.*;

public class Inventory implements InventoryManagement
{
	private List<Items> items;
    private String filename;

    // Constructor
    public Inventory(String filename) {
        this.filename = filename;
        items = new ArrayList<>();
        loadItems();
    }

    // Load items from file
    private void loadItems() {   	
    	File file = new File(filename);
    	
    	if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) 
            	{
                	e.printStackTrace();
            	}
    	}
            
        else {
	        try {
	            BufferedReader reader = new BufferedReader(new FileReader(filename));
	            String line;
	            while ((line = reader.readLine()) != null) {
	                String[] parts = line.split(",");
	                int id = Integer.parseInt(parts[0]);
	                String name = parts[1];
	                double price = Double.parseDouble(parts[2]);
	                int quantity = Integer.parseInt(parts[3]);
	                Items item = new Items(id, name, price, quantity);
	                items.add(item);
	            }
	            reader.close();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
       }
    }

    // Save items to file
    public void saveItems() {
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(filename));
            for (Items item : items) {
                writer.write(item.getId() + "," + item.getName() + "," + item.getPrice() + "," + item.getQuantity() + "\n");
            }
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Method to add an item to the inventory
    @Override
    public void addItem(Items item) {
    	int initialQuantity = item.getQuantity(); // Get the initial quantity
        item.setInitialQuantity(initialQuantity);
        items.add(item);
        saveInitialQuantities(); 
        saveItems();    
    }

    private void saveInitialQuantities() {
	    try (BufferedWriter writer = new BufferedWriter(new FileWriter("initial_quantities.txt"))) {
	        for (Items item : items) {
	            writer.write(item.getId() + "," + item.getInitialQuantity() + "\n");
	        }
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}
    
    // Method to remove an item from the inventory
    @Override
    public void removeItem(int itemId) {
        items.removeIf(item -> item.getId() == itemId);
        saveItems();
    }

    @Override
    public void updateItemAdmin(int itemId, String newName, double newPrice) {
        for (Items item : items) {
            if (item.getId() == itemId) {
                // Update attributes
                item.setName(newName);
                item.setPrice(newPrice);
                // No need to break, as an item's ID is assumed to be unique
            }
        }
        saveItems();
    }
    
    // Method to update the quantity of an item in the inventory
    @Override
    public void updateItem(int itemId, String newName, double newPrice, int newQuantity) {
        for (Items item : items) {
            if (item.getId() == itemId) {
                // Update attributes
                item.setName(newName);
                item.setPrice(newPrice);
                item.setQuantity(newQuantity);
                // No need to break, as an item's ID is assumed to be unique
            }
        }
        saveItems();
    }

    // Method to display all items in the inventory
    @Override
    public void displayItems() {
        for (Items item : items) {
        	System.out.println(item);
        }
    }
    
    @Override
    public List<Items> getItems() {
        return items;
    }
    
    // Method to get an item by ID
    public Items getItemById(int itemId) {
        for (Items item : items) {
            if (item.getId() == itemId) {
                return item;
            }
        }
        return null; // Item not found
    }
}
