package SportStoreSystem;

public class Items 
{
	private int id;
    private String name;
    private double price;
    private int quantity;
    private int initialQuantity;
    
    public Items(int id, String name, double price, int quantity)
    {
    	this.id = id;
        this.name = name;
        this.price = price;
        this.quantity = quantity;
        
    }
    
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }
    
    public void setPrice(Double price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    
    public int getInitialQuantity() {
        return initialQuantity;
    }
    
    public void setInitialQuantity(int initialQuantity) {
        this.initialQuantity = initialQuantity;
    }
    @Override
    public String toString() 
    {
        return "ID: " + id + ", Name: " + name + ", Price: $" + price + ", Quantity: " + quantity;
    }
}
