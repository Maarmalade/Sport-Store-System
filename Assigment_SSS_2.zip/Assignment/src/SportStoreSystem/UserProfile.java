package SportStoreSystem;

public abstract class UserProfile 
{
	 	protected String username;
	    protected String password;
	    // Other user profile information fields as needed

	    // Constructor
	    public UserProfile(String username, String password) {
	        this.username = username;
	        this.password = password;
	    }

	    // Method to authenticate user
	    public abstract boolean authenticate(String username, String password); 
    
	    public abstract void register(String username, String password);
	    
	    public abstract void deleteAccount(String username);
}



