package SportStoreSystem;

import java.util.*;

public class Order 
{
	 	private int orderId;
	    private List<Items> items;
	    private double totalAmount;

	    // Constructor
	    public Order(int orderId) {
	        this.orderId = orderId;
	        items = new ArrayList<>();
	        totalAmount = 0.0;
	    }
	    
	    public List<Items> getItems() {
	        return items;
	    }

	    // Method to add an item to the order
	    public void addItem(Items item) {
	    	// Check if the item already exists in the order
	        boolean found = false;
	        for (Items existingItem : items) {
	            if (existingItem.getId() == item.getId()) {
	                // Update the quantity of the existing item
	                existingItem.setQuantity(existingItem.getQuantity() + item.getQuantity());
	                found = true;
	                break;
	            }
	        }
	        // If the item is not found, add it to the order
	        if (!found) {
	            items.add(item);
	        }
	        // Recalculate the total amount
	        calculateTotalAmount();
	    }


	    // Method to remove an item from the order
	    public void removeItem(Items item) {
	        // Remove the specified quantity of the item from the order
	    	items.remove(item);
	        totalAmount -= item.getPrice();
	    }
	    
	    public void calculateTotalAmount()
	    {
	    	totalAmount = 0.0;
	        for (Items orderItem : items) {
	            totalAmount += orderItem.getPrice() * orderItem.getQuantity();
	        }
	    }

	    // Method to display order details
	    public void displayOrder() {
	        System.out.println("Items in order");
	        for (Items item : items) {
	        	System.out.println(item);
	        }
	        System.out.println("Total Amount: $" + totalAmount);
	    }
	    
	    public Items getItemById(int itemId) {
	        // Iterate through the items in the order
	        for (Items item : items) {
	            // If the item ID matches the provided ID, return the item
	            if (item.getId() == itemId) {
	                return item;
	            }
	        }
	        // If no item with the provided ID is found, return null
	        return null;
	    }
	    
	    public boolean isEmpty() {
	        return items.isEmpty();
	    }
}
