package SportStoreSystem;

import java.util.*;

public class Report 
{
	/*
	// Method to generate an inventory report
    public void generateInventoryReport(List<Items> items) {
        System.out.println("Inventory Report:");
        System.out.println("-----------------");
        for (Items item : items) {
            System.out.println("ID: " + item.getId() + ", Name: " + item.getName() + ", Price: $" + item.getPrice() + ", Quantity: " + item.getQuantity());
        }
    }

    // Method to generate a sales report
    public void generateSalesReport(List<Order> orders) {
        System.out.println("Sales Report:");
        System.out.println("-------------");
        double totalSales = 0.0;
        for (Order order : orders) {
            System.out.println("Order ID: " + order.getOrderId() + ", Total Amount: $" + order.getTotalAmount());
            totalSales += order.getTotalAmount();
        }
        System.out.println("Total Sales: $" + totalSales);
    }
    */
}
