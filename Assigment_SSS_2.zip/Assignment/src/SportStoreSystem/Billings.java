package SportStoreSystem;

import java.util.*;
import java.text.DecimalFormat;

public class Billings 
{
	private List<Order> orders;

    // Constructor
    public Billings() {
        orders = new ArrayList<>();
    }

    // Method to place a new order
    public void placeOrder(Order order) {
        orders.add(order);
    }

    // Method to generate bill for an order
    public void generateBill(Order order) {
    	 DecimalFormat df = new DecimalFormat("#.##");
         double totalCost = 0.0;

         // Calculate total cost of the order
         for (Items item : order.getItems()) {
             totalCost += item.getPrice() * item.getQuantity();
         }

         // Example: Apply a 10% discount
         double discount = totalCost * 0.10;
         totalCost -= discount;

         // Example: Apply 8% tax
         double tax = totalCost * 0.08;
         totalCost += tax;
    }

    // Method to display all orders
    public void displayOrders() {
        for (Order order : orders) {
            order.displayOrder();
        }
    }
}
