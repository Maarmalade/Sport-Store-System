package SportStoreSystem;

import java.util.*;

public class SportStoreApps 
{ 
	public static void main(String[] args) {
	 
		Scanner scanner = new Scanner(System.in);
		 
		boolean loginSuccessful = false;
		
		while (!loginSuccessful) {
            System.out.println("Welcome to the Sport Store System!");
            System.out.println("Are you logging in as:");
            System.out.println("1. Admin");
            System.out.println("2. Customer");
            System.out.print("Enter your choice: ");
            
            int userTypeChoice = scanner.nextInt();
            scanner.nextLine();

            switch (userTypeChoice) {
                case 1:
                    loginSuccessful = loginAsAdmin();
                    break;
                case 2:
                    loginSuccessful = loginAsCustomer();
                    break;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
		
		 scanner.close();
    }

    private static boolean loginAsAdmin() {
    	
    	Scanner scanner = new Scanner(System.in);
    	String adminFilename = "admin.txt"; 
    	Inventory inventory = new Inventory("inventory.txt");
        Report report = new Report();	
        Billings billing = new Billings();
        
        
        System.out.println("Enter admin username:");
        String username = scanner.nextLine();
        System.out.println("Enter admin password:");
        String password = scanner.nextLine();

        Admin admin = new Admin(username, password, adminFilename);

        if (admin.authenticate(username, password)) {
        	
        	System.out.println("Welcome to the Sport Store System!");
    		System.out.println("Please select an option:");
    		System.out.println("1. Create Items");
    		System.out.println("2. Manage billing statements");
    		System.out.println("3. Generate report on inventory and sales");
    		System.out.println("4. Create user profile");
    		System.out.println("5. Exit");
    		
    		int adminChoice = scanner.nextInt();
            scanner.nextLine();
            
    		switch (adminChoice)
    		{
    			case 1: 
    				System.out.println("1. Add item to inventory");
    	    		System.out.println("2. Update items from inventory");
    	    		System.out.println("3. Remove items from inventory");
    	    		System.out.print("\n>> ");
    	    		
    	    		int adminOpt = scanner.nextInt();
    	            scanner.nextLine(); 
    	            
    	            switch (adminOpt)
    	            {
    	            	case 1:
    	            		
    	            		System.out.print("\nEnter item ID : ");
    	                    int id = scanner.nextInt();
    	                    scanner.nextLine(); // Consume newline
    	                    
    	                    System.out.print("\nEnter items name : ");
    	                    String name = scanner.nextLine();
    	                    
    	                    System.out.print("\nEnter item price : ");
    	                    double price = scanner.nextDouble();
    	                    
    	                    System.out.print("\nEnter item quantity : ");
    	                    int quantity = scanner.nextInt();
    	                    
    	                    Items newItem = new Items(id, name, price, quantity);
    	                    inventory.addItem(newItem);
    	                    System.out.println("Item added successfully!");
    	                    break;
    	                    
    	            	case 2:
    	            		
    	            		System.out.println("Enter item ID to update items:");
    	            		int itemId = scanner.nextInt();
    	            		scanner.nextLine(); // Consume newline

    	            		
    	            		System.out.println("Enter new name:");
    	            		String newName = scanner.nextLine();

    	            		System.out.println("Enter new price:");
    	            		double newPrice = scanner.nextDouble();

    	            		System.out.println("Enter new quantity:");
    	            		int newQuantity = scanner.nextInt();

    	            		// Update the item with new values
    	            		inventory.updateItem(itemId, newName, newPrice, newQuantity);
    	            		System.out.println("Item updated successfully!");
    	            		break;
    	                    
    	            	case 3:
    	            		
    	            		 System.out.println("Enter item ID to remove from inventory:");
    	                     int removeId = scanner.nextInt();
    	                     inventory.removeItem(removeId);
    	                     System.out.println("Item removed successfully!");
    	                     break;
    	            }
    	            
    	            break;
    	            
    			case 2:
    				
    				System.out.println("Orders:");
                    billing.displayOrders();
                    break;
    				
    			case 3:
    				System.out.println("1. Display inventory");
    	    		System.out.println("2. Generate inventory report");
    	    		System.out.println("3. Generate sales report");
    				
    	    		int adminOpt2 = scanner.nextInt();
    	            scanner.nextLine(); 
    	            
    	            switch (adminOpt2)
    	            {
    	            	case 1:
    	            		System.out.println("Inventory:");
    	                    inventory.displayItems();
    	                    break;
    	                    
    	            	case 2:
    	            		
    	            		System.out.println("Generating inventory report...");
    	                   // report.generateInventoryReport(inventory.getItems());
    	                    break;
    	                    
    	            	case 3:
    	            		break;
    	            }
    	            
    	            break;

    			case 4:
    				System.out.println("Enter new admin username:");
                    String adminUsername = scanner.nextLine();
                    System.out.println("Enter new admin password:");
                    String adminPassword = scanner.nextLine();

                    Admin newAdmin = new Admin(adminUsername, adminPassword, adminFilename);
                    
                    newAdmin.register(adminUsername, adminPassword);
                    
                    System.out.println("New admin registration successful!");
                    scanner.close();
                    return true;
    				
    			case 6:
    				System.out.println("Exiting...");
                    System.exit(0);
                    break;
                    
    			default:
                    System.out.println("Invalid choice! Please try again.");
                    break;
    		}
            
            scanner.close();
            return true;
            
        } else {
            System.out.println("Invalid username or password. Admin login failed. Please try again.");
            scanner.close();
            return false;
        }
    }

    private static boolean loginAsCustomer() {
    	
    	Scanner scanner = new Scanner(System.in);
    	String customerFilename = "customers.txt";	
    	Inventory inventory = new Inventory("inventory.txt");
    	boolean loggedIn = false;
    	Order order = new Order(1);
    	
    	while (!loggedIn) {
	        System.out.println("1. Login as existing customer");
			System.out.println("2. Create user profile");
			System.out.println("3. Quit");
	        System.out.print("Enter your choice: ");
	        int customerOpt = scanner.nextInt();
	        scanner.nextLine();
	
	        switch (customerOpt) {
	            case 1:
	                System.out.println("Enter customer username:");
	                String username = scanner.nextLine();
	                System.out.println("Enter customer password:");
	                String password = scanner.nextLine();
	
	                Customer customer = new Customer(username, password, customerFilename);
	                
	                if (customer.authenticate(username, password)) {
	                	loggedIn = true;
	                	
	                	while (loggedIn) {
		                	System.out.println("Welcome to the Sport Store System!");
		            		System.out.println("Please select an option:");
		            		System.out.println("1. Display inventory");
		            		System.out.println("2. Update/Maintain customer orders"); 
		            		System.out.println("3. Display billings");
		            		System.out.println("4. Exit");
		
		            		int customerChoice = scanner.nextInt();
		                    scanner.nextLine();		                   		                 
		                    
		                    switch (customerChoice)
		                    {
			                    case 1:
			                    	
				            		System.out.println("Inventory:");
				                    inventory.displayItems();
				                    break;
				                    
			                    case 2:
			                    	// Update/Maintain customer orders
			                        boolean maintainOrders = true;
			                      
			                        while (maintainOrders) {
			                            System.out.println("Update/Maintain customer orders:");
			                            System.out.println("1. Place an order");
			                            System.out.println("2. Remove items from an order");
			                            System.out.println("3. Back");
			                            System.out.print("Enter your choice: ");
			                            int maintainChoice = scanner.nextInt();
			                            scanner.nextLine();
			                            			                            
			                            switch (maintainChoice) {
						                    case 1:
						                        // Place an order
						                        boolean continueAddingItems = true;                       
						                        
						                        while (continueAddingItems) {
						                            // Prompt user to enter item details
						                            System.out.println("Enter item ID to add to order:");
						                            int itemId = scanner.nextInt();
						                            scanner.nextLine(); // Consume newline
						                            Items item = inventory.getItemById(itemId);
						                            
						                            if (item != null) {
						                            	 // Prompt user to enter quantity
						                                System.out.println("Enter quantity:");
						                                int quantity = scanner.nextInt();
						                                scanner.nextLine(); // Consume newline
						                                                            

						                                if (quantity > item.getQuantity()) {
						                                    // Quantity exceeds available quantity
						                                    System.out.println("Error: Entered quantity exceeds available quantity. Please try again.");
						                                    System.out.println("Do you want to add more items to the order? (y/n)");
						                                    String choice = scanner.nextLine();
						                                    if (!choice.equalsIgnoreCase("y")) {
						                                        continueAddingItems = false;
						                                        break; // Exit the loop
						                                    }
						                                    continue; // Go to next iteration of the loop
						                                }
						                                
						                                order.addItem(new Items(item.getId(), item.getName(), item.getPrice(), quantity));
						                                inventory.updateItem(itemId, item.getName(), item.getPrice(), item.getQuantity() - quantity);
						                                
					                                    System.out.println("Item added to order successfully!");
			
						                            } 
						                            
						                            else {
						                                System.out.println("Item with ID " + itemId + " not found in inventory.");
						                            }
						                            
						                            // Ask if the customer wants to continue adding items
						                            System.out.println("Do you want to add more items to the order? (y/n)");
						                            String choice = scanner.nextLine();
						                            if (!choice.equalsIgnoreCase("y")) {
						                                continueAddingItems = false;
						                            }
						                        }
						                        break;
						                        
			                        		
						                    case 2:
						                        // Remove items from an order
						                    	System.out.println("Enter the item ID to remove from order :");
						                        int removeItemId = scanner.nextInt();
						                        scanner.nextLine(); // Consume newline
						                        Items item = inventory.getItemById(removeItemId);
						                       
						                       
						                       if (item != null && order.getItems().contains(item)) {
						                           order.removeItem(item);
						                        System.out.println("Item removed from the order successfully!");
						                       }
						                       break;
     
						                    case 3:
						                        // Back
						                        maintainOrders = false;
						                        break;

						                    default:
						                        System.out.println("Invalid choice! Please try again.");
						                        break;
			                            }
			                            break;
			                        }
			                        break;
			                    			
						                    case 3:
						                    	 // View current order
						                        if (!order.isEmpty()) {
						                            System.out.println("\nCurrent Order:");
						                            order.displayOrder();
						                        }
						                            
						                        else {
						                            System.out.println("No orders placed yet.");
						                        }
						                        
						                    	break;
						                    	
						                    case 4:
				                                loggedIn = false;
				                                break;
				                                
						                    default:
						                        System.out.println("Invalid choice! Please try again.");
						                        break;
		                    }
	                	}
	                	break;
	                }
    
	                else {
	                	System.out.println("Invalid username or password. Customer login failed. Please try again.");	
	                    scanner.close();
	                    return false;
	                }                
	               
                
	            case 2:
	            	System.out.println("Enter new customer username:");
	                String customerUsername = scanner.nextLine();
	                System.out.println("Enter new customer password:");
	                String customerPassword = scanner.nextLine();
	
	                Customer newcustomer = new Customer(customerUsername, customerPassword, customerFilename);
	                
	                newcustomer.register(customerUsername, customerPassword);
	                
	                System.out.println("New customer registration successful!");
	                scanner.close();
	                return true;
	                
	            case 3:
	                // Back to main login screen
	                return false; // Exiting the method
	                
	            default:
	                System.out.println("Invalid choice! Please try again.");
	                scanner.close();
	                return false;
	        }
	        break;
    	}  
        scanner.close();
        return loggedIn;
    }
}
	
	