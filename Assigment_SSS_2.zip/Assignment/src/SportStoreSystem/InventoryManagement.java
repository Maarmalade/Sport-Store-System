package SportStoreSystem;

import java.util.*;

public interface InventoryManagement {
	void addItem(Items item);
    void removeItem(int itemId);
    void updateItem(int itemId, String newName, double newPrice, int newQuantity);
    void displayItems();
    List<Items> getItems();
    Items getItemById(int itemId);
}
