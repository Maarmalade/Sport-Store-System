package SportStoreSystem;

import java.io.*;

public class Customer extends UserProfile{
	
	private String customerFilename;
	
	public Customer(String username, String password, String customerFilename) {
	        super(username, password);
	        this.customerFilename = customerFilename;
	    }
	
	    // Method to authenticate customer login 
	@Override
	public boolean authenticate(String username, String password) {
		 try {
	         BufferedReader reader = new BufferedReader(new FileReader(customerFilename));
	         String line;
	         while ((line = reader.readLine()) != null) {
	             String[] parts = line.split(",");
	             String storedUsername = parts[0];
	             String storedPassword = parts[1];
	             if (username.equals(storedUsername) && password.equals(storedPassword)) {
	                 reader.close();
	                 return true;
	             }
	         }
	         reader.close();
	     } catch (IOException e) {
	         e.printStackTrace();
	     }
	     return false;
	 }
	
	public void register(String username, String password) {
        
		File file = new File(customerFilename);
		
		if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) 
            	{
                	e.printStackTrace();
            	}
    	}
		
		else {
	
			try {
	            BufferedWriter writer = new BufferedWriter(new FileWriter(customerFilename, true));
	            writer.write(username + "," + password + "\n");
	            writer.close();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	}
	
	public void deleteAccount(String username) {
		// Deletion logic for customers
		File inputFile = new File(customerFilename);
		File tempFile = new File("tempCustomerFile.txt");

		try {
			BufferedReader reader = new BufferedReader(new FileReader(inputFile));
			BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));

			String lineToRemove = username;
			String currentLine;

			while ((currentLine = reader.readLine()) != null) {
				// trim newline when comparing with lineToRemove
				String trimmedLine = currentLine.trim();
				if (trimmedLine.startsWith(lineToRemove)) continue;
				writer.write(currentLine + System.getProperty("line.separator"));
			}
			writer.close();
			reader.close();
			tempFile.renameTo(inputFile);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
	



